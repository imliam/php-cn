<?php

declare(strict_types=1);

namespace TailwindMerge\Validators;

use TailwindMerge\Contracts\ValidatorContract;
use TailwindMerge\Validators\Concerns\ValidatesArbitraryVariable;

/**
 * @internal
 */
class ArbitraryVariableImageValidator implements ValidatorContract
{
    use ValidatesArbitraryVariable;

    public static function validate(string $value): bool
    {
        return self::getIsArbitraryVariable($value, ['image', 'url'], false);
    }
}
