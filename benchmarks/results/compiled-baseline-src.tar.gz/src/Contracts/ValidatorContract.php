<?php

declare(strict_types=1);

namespace TailwindMerge\Contracts;

/**
 * @internal
 */
interface ValidatorContract
{
    public static function validate(string $value): bool;
}
